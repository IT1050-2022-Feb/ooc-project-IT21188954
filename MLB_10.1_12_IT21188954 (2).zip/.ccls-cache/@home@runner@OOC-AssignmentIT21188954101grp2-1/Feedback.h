#pragma once

class Feedback{

  private:
    char Feedback_ID[4];
    char FbMessage[50];
    char rate[5];

  public:
    Feedback(char fb_no[], char msg[], char rating[] );

    void setFeedback();
    void DisplayFeedback();
    void displayRate();
    
};