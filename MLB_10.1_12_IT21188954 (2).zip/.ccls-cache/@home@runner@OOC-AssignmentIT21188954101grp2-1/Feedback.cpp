#include "Feedback.h"
#include <cstring>
#include <iostream>

using namespace std;

Feedback::Feedback(char fb_no[], char msg[], char rating[] ){
  strcpy(Feedback_ID,fb_no);
  strcpy(FbMessage,msg);
  strcpy(rate,rating);
  
}

void Feedback::setFeedback(){
  
}
void Feedback::DisplayFeedback(){
  
}
void Feedback::displayRate(){
  
}
 