#include "manager.h"
#include "Accident.h"
#include <cstring>
Accident::Accident()
{
  strcpy(AccidentType, "");
  strcpy(AccidentLocation, "");
}
Accident::Accident(const char pAccidentType[],const char pAccidentLocation[])
{
  strcpy(AccidentType, pAccidentType);
  strcpy(AccidentLocation, pAccidentLocation);
}
void Accident::getdetails()
{
}
void Accident:: displaydetails()
{
  
}
Accident::~Accident(){
  
}