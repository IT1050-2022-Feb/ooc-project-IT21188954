#include"manager.h"
define SiZE 2
Class Accident {
  private:
  char AccidentType[40;
  char AccidentLocation[20];
  
  manager* manager[SIZE];

  public:
  Accident();
    Accident(const char pAccidentType[],const char pAccidentLocation[]);
      void setdetails();
      void getdetails();
      
  
};